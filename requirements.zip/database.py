"""Persistencia local em SQLite para atendimentos e respostas."""

from __future__ import annotations

import json
import os
import sqlite3
from pathlib import Path
from typing import Any


BASE_DIR = Path(__file__).resolve().parent
LOCALAPPDATA_DIR = Path(os.environ.get("LOCALAPPDATA", BASE_DIR))
DATA_DIR = LOCALAPPDATA_DIR / "Robo do INSS" / "data"
DB_PATH = DATA_DIR / "triagem.db"


def get_connection() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_database() -> None:
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS atendimentos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                lead_name TEXT NOT NULL,
                lead_phone TEXT,
                flow_id TEXT NOT NULL,
                flow_name TEXT NOT NULL,
                status TEXT NOT NULL,
                result_title TEXT NOT NULL,
                summary TEXT NOT NULL,
                next_step TEXT NOT NULL,
                notes TEXT,
                history_json TEXT NOT NULL,
                benefit_category TEXT,
                estimated_monthly_value REAL,
                estimated_total_value REAL
            )
            """
        )
        ensure_column(conn, "benefit_category", "TEXT")
        ensure_column(conn, "estimated_monthly_value", "REAL")
        ensure_column(conn, "estimated_total_value", "REAL")
        conn.commit()


def ensure_column(conn: sqlite3.Connection, column_name: str, column_type: str) -> None:
    columns = {
        row["name"]
        for row in conn.execute("PRAGMA table_info(atendimentos)").fetchall()
    }
    if column_name not in columns:
        conn.execute(f"ALTER TABLE atendimentos ADD COLUMN {column_name} {column_type}")


def save_attendance(
    *,
    lead_name: str,
    lead_phone: str,
    flow_id: str,
    flow_name: str,
    status: str,
    result_title: str,
    summary: str,
    next_step: str,
    notes: str,
    history: list[dict[str, Any]],
    benefit_category: str | None = None,
    estimated_monthly_value: float | None = None,
    estimated_total_value: float | None = None,
) -> int:
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO atendimentos (
                lead_name,
                lead_phone,
                flow_id,
                flow_name,
                status,
                result_title,
                summary,
                next_step,
                notes,
                history_json,
                benefit_category,
                estimated_monthly_value,
                estimated_total_value
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                lead_name,
                lead_phone,
                flow_id,
                flow_name,
                status,
                result_title,
                summary,
                next_step,
                notes,
                json.dumps(history, ensure_ascii=True),
                benefit_category,
                estimated_monthly_value,
                estimated_total_value,
            ),
        )
        conn.commit()
        return int(cursor.lastrowid)


def list_recent_attendances(limit: int = 10) -> list[sqlite3.Row]:
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT
                id,
                created_at,
                lead_name,
                flow_name,
                status,
                result_title
            FROM atendimentos
            ORDER BY id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
    return rows


def search_attendances(
    *,
    lead_query: str = "",
    flow_name: str = "",
    status: str = "",
    limit: int = 50,
) -> list[sqlite3.Row]:
    conditions: list[str] = []
    params: list[Any] = []

    if lead_query:
        conditions.append("(lead_name LIKE ? OR lead_phone LIKE ?)")
        like = f"%{lead_query}%"
        params.extend([like, like])
    if flow_name and flow_name != "Todos":
        conditions.append("flow_name = ?")
        params.append(flow_name)
    if status and status != "Todos":
        conditions.append("status = ?")
        params.append(status)

    where_sql = f"WHERE {' AND '.join(conditions)}" if conditions else ""

    with get_connection() as conn:
        rows = conn.execute(
            f"""
            SELECT
                id,
                created_at,
                lead_name,
                lead_phone,
                flow_name,
                status,
                result_title,
                benefit_category,
                estimated_monthly_value,
                estimated_total_value
            FROM atendimentos
            {where_sql}
            ORDER BY id DESC
            LIMIT ?
            """,
            (*params, limit),
        ).fetchall()
    return rows


def get_attendance_details(attendance_id: int) -> sqlite3.Row | None:
    with get_connection() as conn:
        row = conn.execute(
            """
            SELECT
                id,
                created_at,
                lead_name,
                lead_phone,
                flow_id,
                flow_name,
                status,
                result_title,
                summary,
                next_step,
                notes,
                history_json,
                benefit_category,
                estimated_monthly_value,
                estimated_total_value
            FROM atendimentos
            WHERE id = ?
            """,
            (attendance_id,),
        ).fetchone()
    return row


def load_history(history_json: str) -> list[dict[str, Any]]:
    if not history_json:
        return []
    return json.loads(history_json)


def get_dashboard_summary() -> dict[str, Any]:
    with get_connection() as conn:
        total = conn.execute("SELECT COUNT(*) AS total FROM atendimentos").fetchone()["total"]
        by_status = conn.execute(
            """
            SELECT status, COUNT(*) AS total
            FROM atendimentos
            GROUP BY status
            ORDER BY total DESC
            """
        ).fetchall()
        by_flow = conn.execute(
            """
            SELECT flow_name, COUNT(*) AS total
            FROM atendimentos
            GROUP BY flow_name
            ORDER BY total DESC, flow_name ASC
            """
        ).fetchall()
        recent_days = conn.execute(
            """
            SELECT DATE(created_at) AS day, COUNT(*) AS total
            FROM atendimentos
            GROUP BY DATE(created_at)
            ORDER BY day DESC
            LIMIT 7
            """
        ).fetchall()
        conversion_by_flow = conn.execute(
            """
            SELECT flow_name, status, COUNT(*) AS total
            FROM atendimentos
            GROUP BY flow_name, status
            ORDER BY flow_name ASC, status ASC
            """
        ).fetchall()

    return {
        "total": total,
        "by_status": by_status,
        "by_flow": by_flow,
        "recent_days": list(reversed(recent_days)),
        "conversion_by_flow": conversion_by_flow,
    }
