@echo off
setlocal

set "APP_DIR=C:\Users\bruno\OneDrive\Desktop\Robo do INSS"
set "APP_FILE=%APP_DIR%\app.py"
set "PYTHON_EXE=C:\Users\bruno\AppData\Local\Python\pythoncore-3.14-64\python.exe"
set "APP_URL=http://localhost:8501"

if not exist "%APP_FILE%" (
    echo Arquivo nao encontrado:
    echo %APP_FILE%
    pause
    exit /b 1
)

cd /d "%APP_DIR%"

echo Encerrando instancias antigas do Streamlit/Python...
taskkill /F /IM streamlit.exe >nul 2>&1
taskkill /F /IM python.exe >nul 2>&1
taskkill /F /IM pythonw.exe >nul 2>&1
timeout /t 2 /nobreak >nul

echo Iniciando Robo do INSS...
if exist "%PYTHON_EXE%" (
    start "Robo do INSS - Streamlit" "%PYTHON_EXE%" -m streamlit run "%APP_FILE%"
) else (
    start "Robo do INSS - Streamlit" py -m streamlit run "%APP_FILE%"
)

echo Aguardando a aplicacao subir...
timeout /t 6 /nobreak >nul

echo Abrindo navegador...
start "" "%APP_URL%"

echo.
echo Robo do INSS iniciado.
echo Se a pagina nao abrir de imediato, acesse:
echo %APP_URL%

endlocal
