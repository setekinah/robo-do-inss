from __future__ import annotations

from typing import Any

import streamlit as st

from database import (
    get_attendance_details,
    get_dashboard_summary,
    init_database,
    list_recent_attendances,
    load_history,
    save_attendance,
    search_attendances,
)
from flows_data import FLOW_DEFINITIONS
from triage_engine import answer_current_question, create_state, get_current_node, get_result, step_back


st.set_page_config(
    page_title="Robo do INSS",
    page_icon="📋",
    layout="wide",
    initial_sidebar_state="expanded",
)


STATUS_STYLE = {
    "aprovado": ("Qualificado", "#e8fff1", "#18794e"),
    "revisao": ("Em revisao", "#fff6df", "#9a6700"),
    "desqualificado": ("Desqualificado", "#fff1f1", "#b42318"),
}

SALARIO_MINIMO_2026 = 1621.00
TETO_INSS_2026 = 8537.55
APP_VERSION = "v0.5.0"


def inject_styles() -> None:
    st.markdown(
        """
        <style>
        .stApp {
            background:
                radial-gradient(circle at top left, rgba(21, 97, 109, 0.10), transparent 30%),
                radial-gradient(circle at bottom right, rgba(208, 126, 47, 0.10), transparent 28%),
                linear-gradient(135deg, #f8f4ee 0%, #efe5d7 100%);
        }
        .hero-card, .surface-card {
            border: 1px solid rgba(47, 36, 24, 0.08);
            border-radius: 20px;
            padding: 1.2rem 1.3rem;
            background: rgba(255, 250, 244, 0.88);
            box-shadow: 0 12px 34px rgba(47, 36, 24, 0.08);
        }
        .hero-title {
            font-size: 2.5rem;
            font-weight: 700;
            line-height: 1.04;
            margin: 0 0 0.35rem 0;
            color: #2f2418;
        }
        .eyebrow {
            text-transform: uppercase;
            letter-spacing: 0.16em;
            font-size: 0.72rem;
            font-weight: 700;
            color: #d97706;
            margin-bottom: 0.6rem;
        }
        .hero-copy {
            color: #6e5d4c;
            line-height: 1.6;
            margin-bottom: 0;
        }
        .status-chip {
            display: inline-block;
            padding: 0.35rem 0.75rem;
            border-radius: 999px;
            font-weight: 700;
            font-size: 0.85rem;
            margin-bottom: 0.8rem;
        }
        .history-item {
            border-left: 4px solid #15616d;
            padding: 0.65rem 0.85rem;
            margin-bottom: 0.65rem;
            background: rgba(255,255,255,0.7);
            border-radius: 12px;
        }
        .muted {
            color: #705e4b;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def ensure_session_defaults() -> None:
    if "selected_flow_id" not in st.session_state:
        st.session_state.selected_flow_id = next(iter(FLOW_DEFINITIONS.keys()))
    if "triage_state" not in st.session_state:
        flow_id = st.session_state.selected_flow_id
        st.session_state.triage_state = create_state(flow_id, FLOW_DEFINITIONS[flow_id])
    if "saved_result_id" not in st.session_state:
        st.session_state.saved_result_id = None
    if "sm_estimate" not in st.session_state:
        st.session_state.sm_estimate = None
    if "selected_attendance_id" not in st.session_state:
        st.session_state.selected_attendance_id = None


def reset_triage(flow_id: str | None = None) -> None:
    target_flow_id = flow_id or st.session_state.selected_flow_id
    st.session_state.selected_flow_id = target_flow_id
    st.session_state.triage_state = create_state(target_flow_id, FLOW_DEFINITIONS[target_flow_id])
    st.session_state.saved_result_id = None
    st.session_state.sm_estimate = None


def render_header() -> None:
    total_flows = len(FLOW_DEFINITIONS)
    flow_names = ", ".join(flow["name"] for flow in FLOW_DEFINITIONS.values())
    col1, col2 = st.columns([1.4, 1.0], gap="large")
    with col1:
        st.markdown(
            """
            <div class="hero-card">
              <div class="eyebrow">Triagem local em Python</div>
              <div class="hero-title">Robo do INSS</div>
              <p class="hero-copy">
                Sistema local de triagem inteligente para atendimento previdenciario.
                Ele conduz o atendente pelo fluxo, classifica o lead e grava o resultado em SQLite.
              </p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.caption(f"Versao atual do sistema: {APP_VERSION}")
    with col2:
        st.markdown(
            f"""
            <div class="surface-card">
              <div class="eyebrow">Cobertura atual</div>
              <p class="hero-copy">
                O sistema esta com {total_flows} fluxos ativos no momento.
              </p>
              <p class="hero-copy">{flow_names}</p>
            </div>
            """,
            unsafe_allow_html=True,
        )


def render_sidebar() -> None:
    st.sidebar.title("Operacao")
    st.sidebar.caption(f"Build carregada: {APP_VERSION}")
    st.sidebar.caption("Historico salvo localmente em SQLite")

    for row in list_recent_attendances(limit=8):
        label, _, color = STATUS_STYLE.get(row["status"], ("Status", "#f4f4f4", "#555555"))
        st.sidebar.markdown(
            (
                f"**#{row['id']} - {row['lead_name']}**  \n"
                f"{row['flow_name']}  \n"
                f":{color}[{label}]  \n"
                f"{row['created_at']}"
            )
        )
        st.sidebar.divider()


def render_lead_form() -> dict[str, Any]:
    st.subheader("Cadastro do atendimento")
    options = {flow["name"]: flow_id for flow_id, flow in FLOW_DEFINITIONS.items()}
    flow_names = list(options.keys())
    current_flow_name = FLOW_DEFINITIONS[st.session_state.selected_flow_id]["name"]
    current_index = flow_names.index(current_flow_name)

    col1, col2 = st.columns(2)
    with col1:
        name = st.text_input("Nome do lead", key="lead_name", placeholder="Ex.: Maria da Silva")
        phone = st.text_input("Telefone", key="lead_phone", placeholder="(11) 99999-9999")
    with col2:
        chosen_flow_name = st.selectbox("Tipo de atendimento", flow_names, index=current_index)
        notes = st.text_area("Observacoes", key="lead_notes", placeholder="Contexto rapido do caso", height=103)

    selected_flow_id = options[chosen_flow_name]
    if selected_flow_id != st.session_state.selected_flow_id:
        reset_triage(selected_flow_id)
        st.rerun()

    return {
        "lead_name": name.strip(),
        "lead_phone": phone.strip(),
        "lead_notes": notes.strip(),
        "flow_id": selected_flow_id,
    }


def render_history(history: list[dict[str, str]]) -> None:
    st.subheader("Historico da sessao")
    if not history:
        st.info("Nenhuma resposta registrada ainda.")
        return

    for index, item in enumerate(history, start=1):
        st.markdown(
            (
                '<div class="history-item">'
                f"<strong>{index}. {item['node_code']}</strong><br>"
                f"{item['question']}<br>"
                f"<span class='muted'>Resposta: {item['answer']}</span>"
                "</div>"
            ),
            unsafe_allow_html=True,
        )


def format_currency(value: float) -> str:
    formatted = f"{value:,.2f}"
    return f"R$ {formatted.replace(',', 'X').replace('.', ',').replace('X', '.')}"


def clamp_benefit_value(value: float) -> float:
    return min(max(value, SALARIO_MINIMO_2026), TETO_INSS_2026)


def render_salario_maternidade_calculator() -> None:
    st.subheader("Calculadora de Salario-Maternidade")
    st.caption("Estimativa inicial com base nas regras informadas para 2026.")

    category = st.selectbox(
        "Categoria da segurada",
        ["CLT", "MEI", "Autonoma / Facultativa", "Desempregada"],
        key="sm_category",
    )

    monthly_value = SALARIO_MINIMO_2026
    note = ""

    if category == "CLT":
        remuneration_type = st.radio(
            "Tipo de remuneracao",
            ["Salario fixo", "Remuneracao variavel"],
            key="sm_clt_type",
            horizontal=True,
        )
        if remuneration_type == "Salario fixo":
            salary = st.number_input(
                "Ultimo salario de contribuicao",
                min_value=0.0,
                step=100.0,
                value=SALARIO_MINIMO_2026,
                key="sm_clt_fixed_salary",
            )
            monthly_value = clamp_benefit_value(salary)
            note = "Para CLT com salario fixo, a estimativa usa o ultimo salario de contribuicao."
        else:
            salaries = []
            cols = st.columns(3)
            for index in range(6):
                with cols[index % 3]:
                    salaries.append(
                        st.number_input(
                            f"Salario {index + 1}",
                            min_value=0.0,
                            step=100.0,
                            value=SALARIO_MINIMO_2026,
                            key=f"sm_clt_var_{index}",
                        )
                    )
            monthly_value = clamp_benefit_value(sum(salaries) / 6 if salaries else SALARIO_MINIMO_2026)
            note = "Para CLT com remuneracao variavel, a estimativa usa a media dos 6 ultimos salarios."

    elif category == "MEI":
        mei_mode = st.radio(
            "Tipo de contribuicao",
            ["MEI padrao", "MEI com complementacao de 20%"],
            key="sm_mei_mode",
            horizontal=True,
        )
        if mei_mode == "MEI padrao":
            monthly_value = SALARIO_MINIMO_2026
            note = "Para MEI padrao, a estimativa considera o salario minimo de 2026."
        else:
            contribution_count = st.slider(
                "Quantidade de contribuicoes consideradas",
                min_value=1,
                max_value=12,
                value=12,
                key="sm_mei_count",
            )
            values = []
            cols = st.columns(3)
            for index in range(contribution_count):
                with cols[index % 3]:
                    values.append(
                        st.number_input(
                            f"Contribuicao {index + 1}",
                            min_value=0.0,
                            step=100.0,
                            value=SALARIO_MINIMO_2026,
                            key=f"sm_mei_comp_{index}",
                        )
                    )
            monthly_value = clamp_benefit_value(sum(values) / len(values))
            note = "Para MEI com complementacao, a estimativa segue a media das contribuicoes informadas."

    elif category == "Autonoma / Facultativa":
        contribution_count = st.slider(
            "Quantidade de contribuicoes consideradas",
            min_value=1,
            max_value=12,
            value=12,
            key="sm_aut_count",
        )
        values = []
        cols = st.columns(3)
        for index in range(contribution_count):
            with cols[index % 3]:
                values.append(
                    st.number_input(
                        f"Contribuicao {index + 1}",
                        min_value=0.0,
                        step=100.0,
                        value=SALARIO_MINIMO_2026,
                        key=f"sm_aut_{index}",
                    )
                )
        monthly_value = clamp_benefit_value(sum(values) / len(values))
        note = (
            "Para autonoma ou facultativa, a estimativa usa a media das contribuicoes informadas, "
            "respeitando minimo e teto."
        )

    elif category == "Desempregada":
        contribution_count = st.slider(
            "Quantidade de contribuicoes consideradas",
            min_value=1,
            max_value=12,
            value=12,
            key="sm_des_count",
        )
        values = []
        cols = st.columns(3)
        for index in range(contribution_count):
            with cols[index % 3]:
                values.append(
                    st.number_input(
                        f"Contribuicao {index + 1}",
                        min_value=0.0,
                        step=100.0,
                        value=SALARIO_MINIMO_2026,
                        key=f"sm_des_{index}",
                    )
                )
        monthly_value = clamp_benefit_value(sum(values) / len(values))
        note = "Para desempregada, a estimativa usa a media das contribuicoes disponiveis."

    total_benefit = monthly_value * 4
    st.session_state.sm_estimate = {
        "category": category,
        "monthly_value": monthly_value,
        "total_value": total_benefit,
    }
    st.metric("Valor mensal estimado", format_currency(monthly_value))
    st.metric("Total estimado em 120 dias", format_currency(total_benefit))
    st.info(note)
    st.caption(
        f"Referencia 2026: minimo {format_currency(SALARIO_MINIMO_2026)} | "
        f"teto {format_currency(TETO_INSS_2026)}"
    )


def render_question_panel(flow: dict[str, Any], form_data: dict[str, Any]) -> None:
    triage_state = st.session_state.triage_state
    node = get_current_node(triage_state, flow)

    if node is None:
        render_result_panel(flow, form_data)
        return

    st.subheader("Triagem guiada")
    st.caption(f"{flow['name']} | {node['code']} | Pergunta {len(triage_state.history) + 1}")
    st.markdown(f"### {node['title']}")
    st.write(node.get("help", ""))

    option_cols = st.columns(len(node["options"]))
    for col, option in zip(option_cols, node["options"]):
        with col:
            st.markdown(" ")
            if st.button(
                option["label"],
                key=f"{node['id']}_{option['label']}",
                use_container_width=True,
                help=option["description"],
            ):
                new_state, _ = answer_current_question(triage_state, flow, option["label"])
                st.session_state.triage_state = new_state
                st.session_state.saved_result_id = None
                st.rerun()
            st.caption(option["description"])

    controls = st.columns([1, 1, 4])
    with controls[0]:
        if st.button("Voltar", disabled=not triage_state.history, use_container_width=True):
            st.session_state.triage_state = step_back(triage_state, flow)
            st.session_state.saved_result_id = None
            st.rerun()
    with controls[1]:
        if st.button("Reiniciar fluxo", use_container_width=True):
            reset_triage(flow["id"])
            st.rerun()


def render_result_panel(flow: dict[str, Any], form_data: dict[str, Any]) -> None:
    triage_state = st.session_state.triage_state
    result = get_result(triage_state, flow)
    if result is None:
        st.info("Selecione um fluxo e inicie a triagem.")
        return

    label, background, color = STATUS_STYLE[result["status"]]
    st.subheader("Resultado final")
    st.markdown(
        (
            f"<div class='status-chip' style='background:{background}; color:{color};'>{label}</div>"
            f"<div class='surface-card'><h3>{result['title']}</h3>"
            f"<p><strong>Resumo:</strong> {result['summary']}</p>"
            f"<p><strong>Proximo passo:</strong> {result['next_step']}</p>"
            f"<p><strong>Lead:</strong> {form_data['lead_name'] or 'Nao informado'}"
            f" | <strong>Telefone:</strong> {form_data['lead_phone'] or 'Nao informado'}</p>"
            "</div>"
        ),
        unsafe_allow_html=True,
    )

    sm_estimate = st.session_state.sm_estimate if flow["id"] == "salarioMaternidade" else None
    if sm_estimate:
        st.markdown(
            (
                "<div class='surface-card'>"
                "<h4>Estimativa registrada</h4>"
                f"<p><strong>Categoria:</strong> {sm_estimate['category']}</p>"
                f"<p><strong>Valor mensal estimado:</strong> {format_currency(sm_estimate['monthly_value'])}</p>"
                f"<p><strong>Total estimado em 120 dias:</strong> {format_currency(sm_estimate['total_value'])}</p>"
                "</div>"
            ),
            unsafe_allow_html=True,
        )

    col1, col2 = st.columns([1.3, 1])
    with col1:
        if st.button("Salvar atendimento", use_container_width=True):
            saved_id = save_attendance(
                lead_name=form_data["lead_name"] or "Lead sem nome",
                lead_phone=form_data["lead_phone"],
                flow_id=flow["id"],
                flow_name=flow["name"],
                status=result["status"],
                result_title=result["title"],
                summary=result["summary"],
                next_step=result["next_step"],
                notes=form_data["lead_notes"],
                history=triage_state.history,
                benefit_category=sm_estimate["category"] if sm_estimate else None,
                estimated_monthly_value=sm_estimate["monthly_value"] if sm_estimate else None,
                estimated_total_value=sm_estimate["total_value"] if sm_estimate else None,
            )
            st.session_state.saved_result_id = saved_id
            st.rerun()
    with col2:
        if st.button("Nova triagem", use_container_width=True):
            reset_triage(flow["id"])
            st.rerun()

    if st.session_state.saved_result_id:
        st.success(f"Atendimento salvo com sucesso. Registro #{st.session_state.saved_result_id}.")


def render_attendance_consultation() -> None:
    st.subheader("Consulta de atendimentos")

    dashboard = get_dashboard_summary()
    metric_cols = st.columns(4)
    qualified_total = next((row["total"] for row in dashboard["by_status"] if row["status"] == "aprovado"), 0)
    revision_total = next((row["total"] for row in dashboard["by_status"] if row["status"] == "revisao"), 0)
    disqualified_total = next((row["total"] for row in dashboard["by_status"] if row["status"] == "desqualificado"), 0)

    metric_cols[0].metric("Total de atendimentos", int(dashboard["total"]))
    metric_cols[1].metric("Qualificados", int(qualified_total))
    metric_cols[2].metric("Em revisao", int(revision_total))
    metric_cols[3].metric("Desqualificados", int(disqualified_total))

    chart_left, chart_right = st.columns(2, gap="large")
    with chart_left:
        st.markdown("#### Atendimentos por fluxo")
        if dashboard["by_flow"]:
            flow_chart_data = [
                {"Fluxo": row["flow_name"], "Total": int(row["total"])}
                for row in dashboard["by_flow"]
            ]
            st.bar_chart(flow_chart_data, x="Fluxo", y="Total", horizontal=True)
        else:
            st.info("Sem dados suficientes para o grafico por fluxo.")

    with chart_right:
        st.markdown("#### Evolucao recente")
        if dashboard["recent_days"]:
            daily_chart_data = [
                {"Dia": row["day"], "Total": int(row["total"])}
                for row in dashboard["recent_days"]
            ]
            st.line_chart(daily_chart_data, x="Dia", y="Total")
        else:
            st.info("Sem dados suficientes para a evolucao diaria.")

    st.markdown("#### Ranking por fluxo")
    if dashboard["by_flow"]:
        for row in dashboard["by_flow"]:
            st.markdown(f"- {row['flow_name']}: {int(row['total'])} atendimento(s)")
    else:
        st.info("Ainda nao ha atendimentos salvos.")

    st.markdown("#### Conversao por fluxo")
    if dashboard["conversion_by_flow"]:
        conversion_map: dict[str, dict[str, int]] = {}
        for row in dashboard["conversion_by_flow"]:
            flow_name = row["flow_name"]
            status = row["status"]
            total = int(row["total"])
            if flow_name not in conversion_map:
                conversion_map[flow_name] = {
                    "Qualificados": 0,
                    "Em revisao": 0,
                    "Desqualificados": 0,
                }
            if status == "aprovado":
                conversion_map[flow_name]["Qualificados"] = total
            elif status == "revisao":
                conversion_map[flow_name]["Em revisao"] = total
            elif status == "desqualificado":
                conversion_map[flow_name]["Desqualificados"] = total

        conversion_chart_data = [
            {"Fluxo": flow_name, **totals}
            for flow_name, totals in conversion_map.items()
        ]
        st.bar_chart(
            conversion_chart_data,
            x="Fluxo",
            y=["Qualificados", "Em revisao", "Desqualificados"],
        )

        for flow_name, totals in conversion_map.items():
            st.markdown(
                (
                    f"- {flow_name}: "
                    f"{totals['Qualificados']} qualificado(s), "
                    f"{totals['Em revisao']} em revisao, "
                    f"{totals['Desqualificados']} desqualificado(s)"
                )
            )
    else:
        st.info("Ainda nao ha dados suficientes para conversao por fluxo.")

    filter_col1, filter_col2, filter_col3 = st.columns([1.6, 1, 1])
    with filter_col1:
        lead_query = st.text_input(
            "Buscar por nome ou telefone",
            key="consult_lead_query",
            placeholder="Ex.: Maria ou 1199999",
        ).strip()
    with filter_col2:
        flow_name = st.selectbox(
            "Fluxo",
            ["Todos", *[flow["name"] for flow in FLOW_DEFINITIONS.values()]],
            key="consult_flow_name",
        )
    with filter_col3:
        status_label_map = {"Todos": "Todos", "Qualificado": "aprovado", "Em revisao": "revisao", "Desqualificado": "desqualificado"}
        status_label = st.selectbox("Status", list(status_label_map.keys()), key="consult_status")

    rows = search_attendances(
        lead_query=lead_query,
        flow_name=flow_name,
        status=status_label_map[status_label],
        limit=100,
    )

    left, right = st.columns([1.1, 1.4], gap="large")
    with left:
        if not rows:
            st.info("Nenhum atendimento encontrado com esses filtros.")
        else:
            for row in rows:
                label, background, color = STATUS_STYLE.get(row["status"], ("Status", "#f4f4f4", "#555555"))
                st.markdown(
                    (
                        f"<div class='surface-card'>"
                        f"<strong>#{row['id']} - {row['lead_name']}</strong><br>"
                        f"<span class='muted'>{row['flow_name']} | {row['created_at']}</span><br>"
                        f"<span class='status-chip' style='background:{background}; color:{color};'>{label}</span>"
                        f"<div>{row['result_title']}</div>"
                        "</div>"
                    ),
                    unsafe_allow_html=True,
                )
                if st.button(f"Abrir #{row['id']}", key=f"open_attendance_{row['id']}", use_container_width=True):
                    st.session_state.selected_attendance_id = int(row["id"])
                    st.rerun()

    with right:
        if not st.session_state.selected_attendance_id and rows:
            st.session_state.selected_attendance_id = int(rows[0]["id"])

        if not st.session_state.selected_attendance_id:
            st.info("Selecione um atendimento para ver os detalhes.")
            return

        details = get_attendance_details(int(st.session_state.selected_attendance_id))
        if details is None:
            st.warning("Atendimento nao encontrado.")
            return

        label, background, color = STATUS_STYLE.get(details["status"], ("Status", "#f4f4f4", "#555555"))
        st.markdown(
            (
                f"<div class='status-chip' style='background:{background}; color:{color};'>{label}</div>"
                f"<div class='surface-card'><h3>#{details['id']} - {details['lead_name']}</h3>"
                f"<p><strong>Fluxo:</strong> {details['flow_name']}</p>"
                f"<p><strong>Telefone:</strong> {details['lead_phone'] or 'Nao informado'}</p>"
                f"<p><strong>Data:</strong> {details['created_at']}</p>"
                f"<p><strong>Resultado:</strong> {details['result_title']}</p>"
                f"<p><strong>Resumo:</strong> {details['summary']}</p>"
                f"<p><strong>Proximo passo:</strong> {details['next_step']}</p>"
                f"<p><strong>Observacoes:</strong> {details['notes'] or 'Sem observacoes'}</p>"
                "</div>"
            ),
            unsafe_allow_html=True,
        )

        if details["benefit_category"] or details["estimated_monthly_value"] or details["estimated_total_value"]:
            monthly = details["estimated_monthly_value"]
            total = details["estimated_total_value"]
            st.markdown(
                (
                    "<div class='surface-card'><h4>Dados de Salario-Maternidade</h4>"
                    f"<p><strong>Categoria:</strong> {details['benefit_category'] or 'Nao informada'}</p>"
                    f"<p><strong>Valor mensal estimado:</strong> {format_currency(monthly) if monthly else 'Nao informado'}</p>"
                    f"<p><strong>Total estimado:</strong> {format_currency(total) if total else 'Nao informado'}</p>"
                    "</div>"
                ),
                unsafe_allow_html=True,
            )

        history = load_history(details["history_json"])
        st.markdown("#### Historico de respostas")
        if not history:
            st.info("Sem historico de respostas registrado.")
        else:
            for index, item in enumerate(history, start=1):
                st.markdown(
                    (
                        '<div class="history-item">'
                        f"<strong>{index}. {item['node_code']}</strong><br>"
                        f"{item['question']}<br>"
                        f"<span class='muted'>Resposta: {item['answer']}</span>"
                        "</div>"
                    ),
                    unsafe_allow_html=True,
                )


def main() -> None:
    init_database()
    inject_styles()
    ensure_session_defaults()
    render_sidebar()
    render_header()

    tab_triagem, tab_consulta = st.tabs(["Triagem", "Consulta"])

    with tab_triagem:
        left, right = st.columns([1.35, 1], gap="large")
        with left:
            form_data = render_lead_form()
            st.divider()
            flow = FLOW_DEFINITIONS[st.session_state.selected_flow_id]
            render_question_panel(flow, form_data)
        with right:
            if st.session_state.selected_flow_id == "salarioMaternidade":
                render_salario_maternidade_calculator()
                st.divider()
            render_history(st.session_state.triage_state.history)

    with tab_consulta:
        render_attendance_consultation()


if __name__ == "__main__":
    main()
