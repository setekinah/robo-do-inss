@echo off
setlocal

set "APP_DIR=C:\Users\bruno\OneDrive\Desktop\Robo do INSS"
set "APP_FILE=%APP_DIR%\app.py"
set "PYTHON_EXE=C:\Users\bruno\AppData\Local\Python\pythoncore-3.14-64\python.exe"

if not exist "%APP_FILE%" (
    echo Arquivo nao encontrado:
    echo %APP_FILE%
    pause
    exit /b 1
)

cd /d "%APP_DIR%"

if exist "%PYTHON_EXE%" (
    "%PYTHON_EXE%" -m streamlit run "%APP_FILE%"
) else (
    py -m streamlit run "%APP_FILE%"
)

if errorlevel 1 (
    echo.
    echo Nao foi possivel iniciar o aplicativo.
    echo Verifique se o Python e o Streamlit estao instalados corretamente.
    pause
)

endlocal
